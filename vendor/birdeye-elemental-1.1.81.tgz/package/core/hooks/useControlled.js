import{useRef as r,useState as t,useCallback as o}from"react";function e(e,n){const{current:c}=r(void 0!==e),[u,a]=t(n);return[c?e:u,o(r=>{c||a(r)},[])]}export{e as default};
