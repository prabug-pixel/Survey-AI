import{useEditorMaybe as e}from"@grapesjs/react";const t=()=>{const t=e();return null==t?void 0:t.getSelected()};export{t as useSelectedComponent};
