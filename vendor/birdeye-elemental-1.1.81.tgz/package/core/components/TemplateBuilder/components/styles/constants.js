const o=["text-align","font","font-family","font-size","font-weight","color","font-color","line-height"];export{o as FILTERED_TEXT_PROPERTIES};
