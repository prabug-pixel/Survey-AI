import{MODULE_NAMES as t}from"../constants.js";const{ENT_REPORT:a}=t,r=t=>{if(t===a)return"/dashboard/analytics-dash/create"};export{r as createNewPathName};
