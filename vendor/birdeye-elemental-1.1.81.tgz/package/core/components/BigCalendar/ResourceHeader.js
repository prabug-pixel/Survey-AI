import e from"prop-types";import r from"react";const t=e=>{let{label:t}=e;return r.createElement(r.Fragment,null,t)};t.propTypes={label:e.node,index:e.number,resource:e.object};export{t as default};
