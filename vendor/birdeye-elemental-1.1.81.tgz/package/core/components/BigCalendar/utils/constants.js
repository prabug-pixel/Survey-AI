let E={PREVIOUS:"PREV",NEXT:"NEXT",TODAY:"TODAY",DATE:"DATE"},T={MONTH:"month",WEEK:"week",LIST:"list",WORK_WEEK:"work_week",DAY:"day",AGENDA:"agenda"};export{E as navigate,T as views};
